Funciones útiles para la asignatura Visión por Computador
del Grado en Ingeniería Informática de la Universidad de Murcia.

